﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;

namespace Sokoban.Lib
{
    public enum DebuggerMode
    {
        OutputWindow,
        File,
        Console
    }

    public static class DebuggerIX
    {
        static TextWriter tw;
        static bool isActive = false;
        private static DebuggerMode debuggerMode = DebuggerMode.OutputWindow;

        static DebuggerIX()
        {
        }

        [Conditional("DEBUG")]
        public static void Start(DebuggerMode debuggerMode)
        {
            if (isActive == false)
            {
                isActive = true;

                DebuggerIX.debuggerMode = debuggerMode;

                if (debuggerMode == DebuggerMode.File)
                {
                    string path = @"D:\Bakalarka\Log\";

                    if (Directory.Exists(path))
                    {
                        string file = path + "Log-" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".txt";
                        tw = new StreamWriter(file, false);
                    }
                    else
                    {
                        DebuggerIX.WriteLine("[Debugger] Path: " + path + " does not exists! Logging is not active!");
                    }
                }
            }
        }


        [Conditional("DEBUG")]
        public static void WriteLine(string s)
        {
            if (isActive == true)
            {
                sendToOutput(s, true);
            }
        }

        [Conditional("DEBUG")]
        public static void WriteLine(string category, string s)
        {
            if (isActive == true)
            {
                WriteLine(category, "General", s);
            }
        }

        [Conditional("DEBUG")]
        public static void WriteLine(string category, string subcategory, string s)
        {
            if (isActive == true)
            {
                string time = DateTime.Now.ToString("HH:mm:ss:fff");

                string message = time + " | " 
                    + category.PadRight(21) 
                    + "  |   "
                    + subcategory.PadRight(27)
                    + "  |   "
                    + s;

                sendToOutput(message, true);
            }
        }

        [Conditional("DEBUG")]
        public static void Write(string s)
        {
            if (isActive == true)
            {
                sendToOutput(s);
            }
        }

        [Conditional("DEBUG")]
        private static void sendToOutput(string s)
        {
            sendToOutput(s, false);
        }

        [Conditional("DEBUG")]
        private static void sendToOutput(string s, bool addNewLine)
        {
            if (debuggerMode == DebuggerMode.OutputWindow)
            {
                if (addNewLine == true)
                {
                    Debug.WriteLine(s);
                }
                else
                {
                    Debug.Write(s);
                }
            }
            else if (debuggerMode == DebuggerMode.File)
            {                
                if (addNewLine == true)
                {
                    tw.WriteLine(s);
                }
                else
                {
                    tw.Write(s);
                }
            }
            else if (debuggerMode == DebuggerMode.Console)
            {
                if (addNewLine == true)
                {
                    Console.WriteLine(s);
                }
                else
                {
                    Console.Write(s);
                }
            }
        }

        [Conditional("DEBUG")]
        public static void Close()
        {
            if (isActive)
            {
                if (debuggerMode == DebuggerMode.File)
                {
                    tw.Flush();
                    tw.Close();
                }
            }
        }
    }
}
