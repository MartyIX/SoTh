﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sokoban.View {
    public interface IBaseView {
        string Name { get; set; }
    }
}
