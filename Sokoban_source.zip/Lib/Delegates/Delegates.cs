﻿namespace Sokoban.Lib
{
    public delegate void GameObjectMovedDel(int newX, int newY, char direction);
    public delegate void VoidChangeDelegate();
}