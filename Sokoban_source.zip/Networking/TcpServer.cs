﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using Sokoban.Lib;
using System.Threading;
using System.Net.NetworkInformation;
using Sokoban.Lib.Exceptions;
using System.Windows;

namespace Sokoban.Networking
{
    public class NetworkServer : TcpConnection, IConnection
    {
        private Socket mainSocket = null;
        private string ipAddress = null;
        private int port;
        private string role = "Server";
        private IAsyncResult currentAsyncResult = null;
        private int clientCount = 0;
        private Socket[] workerSocket = new Socket[10];

        public int Backlog
        {
            get;
            set;
        }

        public NetworkServer(int port) : base("Server")
        {
            this.port = port;
        }

        public NetworkServer(string ipAddress, int port) : base("Server")
        {
            this.ipAddress = ipAddress;
            this.port = port;
        }

        public void InitializeConnection()
        {
            receivingInit();
            sendingInit();
            isInitialized = false;

            try
            {
                IPAddress _ip = (this.ipAddress == null || this.ipAddress == "Automatic") 
                    ? IPAddress.Any 
                    : IPAddress.Parse(this.ipAddress);
                
                // Create the listening socket...
                mainSocket = new Socket(AddressFamily.InterNetwork,
                                          SocketType.Stream,
                                          ProtocolType.Tcp);
                IPEndPoint ipLocal = new IPEndPoint(IPAddress.Any, port);
                // Bind to local IP Address...
                mainSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                DebuggerIX.WriteLine("[Net]", role, "Binding");
                mainSocket.Bind(ipLocal);
                DebuggerIX.WriteLine("[Net]", role, "Start listening..");
                mainSocket.Listen(4);
                DebuggerIX.WriteLine("[Net]", role, "BeginAccept for clients");
                currentAsyncResult = mainSocket.BeginAccept(new AsyncCallback(onClientConnect), null);
                DebuggerIX.WriteLine("[Net]", role, "Waiting on a client");
                try
                {
                    waitHandle(currentAsyncResult, 10000);
                }
                catch (TimeoutException e)
                {
                    DebuggerIX.WriteLine("[Net]", role, "Timeout: Connection wasn't established in 10 second time.");
                }
            }
            catch (SocketException se)
            {
                DebuggerIX.WriteLine("[Net]", role, se.ErrorCode + ":  " + se.Message);                
            }
        }


        // This is the call back function, which will be invoked when a client is connected
        private void onClientConnect(IAsyncResult asyn)
        {
            if (currentAsyncResult != asyn) return;

            try
            {
                // Here we complete/end the BeginAccept() asynchronous call
                // by calling EndAccept() - which returns the reference to
                // a new Socket object
                clientSocket = mainSocket.EndAccept(asyn);

                isInitialized = true;

                // Since the main Socket is now free, it can go back and wait for
                // other clients who are attempting to connect
                // mainSocket.BeginAccept(new AsyncCallback(onClientConnect), null);
            }
            catch (ObjectDisposedException)
            {
                DebuggerIX.WriteLine("[Net]", role, "Socket has been closed.");
                isInitialized = false;
            }
            catch (SocketException se)
            {
                DebuggerIX.WriteLine("[Net]", role, "SocketException: " + se.Message);
                isInitialized = false;
            }
            catch (ArgumentException e)
            {
                DebuggerIX.WriteLine("[Net]", role, "ArgumentException: " + e.Message);
                isInitialized = false;
            }

            if (clientSocket!= null && clientSocket.Connected)
            {
                isInitialized = true;
                DebuggerIX.WriteLine("[Net]", role, "OK; Handling  client  at  " +
                    clientSocket.RemoteEndPoint.AddressFamily);
            }
        }

        public override void CloseConnection()
        {
            if (mainSocket != null)
            {
                mainSocket.Close();
            }
            
            base.CloseConnection();
        }

    }
}