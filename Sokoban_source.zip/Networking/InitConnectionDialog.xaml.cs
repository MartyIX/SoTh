﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Sokoban.Presenter;
using Sokoban.Model;
using System.ComponentModel;
using System.Globalization;
using System.Collections.ObjectModel;
using Sokoban.Networking;
using Sokoban.Lib;
using System.Threading;
using Sokoban.Lib.Exceptions;
using System.Net;
using Sokoban.Interfaces;
using Sokoban.Lib.Http;
using Sokoban.Cryptography;
using Sokoban.Model.Xml;

namespace Sokoban.View.SetupNetwork
{
    /// <summary>
    /// Interaction logic for ChooseConnectionWindow.xaml
    /// </summary>
    public partial class InitConnection : Window, INotifyPropertyChanged
    {

        // 
        // API
        //

        public string Status
        {
            get { return _status; }
            set { _status = value; Notify("Status"); }
        }

        public const int MAX_PLAYERS_TO_WAIT_FOR = 3;

        //
        // Private fields
        //

        private delegate void AddAutentizationDelegate(Autentization autentization);
        private delegate void AddMessageDelegate(string message);
        private string _status;
        private ObservableCollection<Autentization> connectingPlayers = new ObservableCollection<Autentization>();
        private int port = 56726;
        private string ipAddress;
        private Thread t1;
        private int endTheThread = 0;
        private string btnListenContent = "Listen";
        private int leaguesID;
        private int roundsID;
        private IProfileRepository profile = null;
        private IErrorMessagesPresenter errorPresenter = null;
        private PendingGamesXmlServerResponse response = null;

        public InitConnection(int leaguesID, int roundsID, IProfileRepository profileRepository, IErrorMessagesPresenter errorPresenter)
        {
            InitializeComponent();
            this.DataContext = this;
            IpAddress = "Automatic";
            this.leaguesID = leaguesID;
            this.roundsID = roundsID;
            this.profile = profileRepository;
            this.errorPresenter = errorPresenter;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request">i.e., "/remote/GetInitLeagues/"</param>
        /// <returns>Response of the server</returns>
        private string getRequestOnServer(string request)
        {
            if (profile == null) throw new UninitializedException("Server name was not initialized.");

            string output;

            if (profile.Server == String.Empty)
            {
                output = "error";
                this.Status = "User is not logged in.";
                errorMessage(ErrorMessageSeverity.Low, "User is not logged in. Please log in and click on 'Refresh'");
            }
            else
            {
                string url = profile.Server.TrimEnd(new char[] { '/' }) + request;

                try
                {
                    output = HttpReq.GetRequest(url, "");
                }
                catch (WebException e)
                {
                    output = "error";
                    this.Status = "Error in communication with the server. Please try again in a while.";
                    errorMessage(ErrorMessageSeverity.Medium, "Error in communication with the server. Additional information: " + e.Message);
                }
                catch (Exception e)
                {
                    output = "error";
                    this.Status = "Unknown error occured. Please try again in a while.";
                    errorMessage(ErrorMessageSeverity.High, "Unknown error in communication with the server. Additional information: " + e.Message);
                }

            }

            return output;
        }

        public int Port
        {
            get { return port; }
            set { port = value; Notify("Port"); }
        }

        public string IpAddress
        {
            get { return ipAddress; }
            set { ipAddress = value; Notify("IpAddress"); }
        }


        public string BtnListenContent
        {
            get { return btnListenContent; }
            set { btnListenContent = value; Notify("BtnListenContent"); }
        }

        public ObservableCollection<Autentization> ConnectingPlayers
        {
            get { return connectingPlayers; }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void AddPlayer(Autentization autentization)
        {
            if (!ConnectingPlayers.Contains(autentization))
            {
                ConnectingPlayers.Add(autentization);
            }
        }

        private void AddMessage(string message)
        {
            tbStatus.Text = tbStatus.Text + message + "\n";
        }

        public void ListenProcessing()
        {
            if (btnListenContent == "Listen")
            {
                addGameOffer();
            }
            else
            {
                cancel();
                deleteGameOffer();
            }

        }

        private void addGameOffer()
        {
            BtnListenContent = "Listen";
            bool success = true;
            try
            {
                start();
            }
            catch (ThreadStateException e)
            {
                success = false;
            }

            if (success)
            {
                string preHash = roundsID.ToString() + profile.SessionID + Hashing.CalculateSHA1(profile.Password, Encoding.Default).ToLower();
                DebuggerIX.WriteLine("[Net]","AddGameOffer","preHash: " + preHash);
                string hash = Hashing.CalculateSHA1(preHash, Encoding.Default).ToLower();
                DebuggerIX.WriteLine("[Net]", "AddGameOffer", "Hash: " + hash);
                string httpReq = "/remote/AddGameOffer/?rounds_id=" + roundsID + "&session_id=" + profile.SessionID + "&hash=" + hash;
                DebuggerIX.WriteLine("[Net]", "AddGameOffer", "HttpReq: " + httpReq);
                string output = getRequestOnServer(httpReq);

                if (output != "error")
                {
                    response = new PendingGamesXmlServerResponse();

                    try
                    {
                        response.Parse(output, PendingGamesXmlServerResponse.ActionType.Add);
                        this.Status = "Initial leagues loaded.";
                    }
                    catch (InvalidStateException e)
                    {
                        this.Status = e.Message;
                        response = null;
                    }

                    if (response == null)
                    {
                        MessageBox.Show("Cannot parse game server answer.");
                        cancel();
                    }
                    else
                    {
                        if (response.Success == true)
                        {
                            this.Status = "Game offer added.";
                            BtnListenContent = "Cancel";
                        }
                        else
                        {
                            MessageBox.Show("Game offer could not be added on the game server.");
                            errorMessage(ErrorMessageSeverity.Medium,
                                "Game offer was not added to the game server. Server's error message:" + response.ErrorMessage);
                            response = null;
                            cancel();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Game server returned error flag. Cannot continue.");
                    cancel();
                }

            }
            else
            {
                MessageBox.Show("There was an error in initialization of network connection.");
            }
        }

        private void deleteGameOffer()
        {
            cancel();
            
            if (response != null && response.OfferID != -1)
            {
                string hash = Hashing.CalculateSHA1(response.OfferID.ToString() +
                    profile.SessionID + Hashing.CalculateSHA1(profile.Password, Encoding.Default).ToLower(), Encoding.Default).ToLower();
                string output = getRequestOnServer("/remote/DeleteGameOffer/?offer_id=" + response.OfferID +
                    "&session_id=" + profile.SessionID + "&hash=" + hash);

                if (output != "error" && output != String.Empty)
                {
                    response = new PendingGamesXmlServerResponse();

                    try
                    {
                        response.Parse(output, PendingGamesXmlServerResponse.ActionType.Delete);
                    }
                    catch (InvalidStateException e)
                    {
                        this.Status = e.Message;
                        response = null;
                    }
                    
                    if (response == null)
                    {
                        MessageBox.Show("Cannot parse game server answer.");
                    }
                    else
                    {
                        if (response.Success == true)
                        {
                            this.Status = "Game offer deleted.";
                            BtnListenContent = "Listen";
                        }
                        else
                        {
                            MessageBox.Show("Game offer could not be deleted from the game server.");
                            errorMessage(ErrorMessageSeverity.Medium, 
                                "Game offer was not deleted from the game server. Server's error message:" + response.ErrorMessage);
                        }                       
                    }
                }
                else
                {
                    MessageBox.Show("Game server returned error flag. Game offer was not deleted.");
                    BtnListenContent = "Listen";
                }
            }
            else
            {
                BtnListenContent = "Listen";
            }
        }


        public void Terminate()
        {
            cancel();
            deleteGameOffer();
        }

        private void start()
        {
            if (t1 == null || t1.ThreadState == ThreadState.Stopped)
            {
                //  Create  a  ThreadStart  instance  using  your  method  as  a  delegate:
                ThreadStart methodDelegate = new ThreadStart(runServer);
                //  Create  a  Thread  instance  using  your  delegate  method:
                t1 = new Thread(methodDelegate);
            }

            if (t1.ThreadState == ThreadState.Unstarted)
            {
                endTheThread = 0;
                ConnectingPlayers.Clear();
                tbStatus.Text = "";

                //  Start  the  thread
                t1.Start();

                tbPort.IsEnabled = false;
                tbIpAddress.IsEnabled = false;
            }
        }


        private void cancel()
        {
            if (t1.ThreadState == ThreadState.Running || t1.ThreadState == ThreadState.WaitSleepJoin)
            {
                t1.Interrupt();
                if (endTheThread == 0)
                {
                    Interlocked.Increment(ref endTheThread);
                }

                tbPort.IsEnabled = false;
                tbIpAddress.IsEnabled = false;
            }                       
        }

        private void runServer()
        {
            string role = "Server";
            NetworkServer ns = new NetworkServer(this.ipAddress, this.port);

            int maxPlayersToWaitFor = MAX_PLAYERS_TO_WAIT_FOR;
            int i = 1;
            AddAutentizationDelegate addPlayer = new AddAutentizationDelegate(AddPlayer);
            AddMessageDelegate addMessage = new AddMessageDelegate(AddMessage);

            try
            {
                while (i <= maxPlayersToWaitFor && endTheThread != 1)
                {
                    Thread.Sleep(3000);
                    DebuggerIX.WriteLine("[Net]", role, "Initialization # " + i + " invoked");
                    Dispatcher.Invoke(addMessage, "Attempt to receive connection #" + i);

                    try
                    {
                        ns.InitializeConnection();
                    }
                    catch (InvalidStateException e)
                    {
                        DebuggerIX.WriteLine("[Net]", role, "InvalidState: " + e.Message);
                        Dispatcher.Invoke(addMessage, "Error:" + e.Message);
                    }
                    catch (TimeoutException e)
                    {
                        DebuggerIX.WriteLine("[Net]", role, "TimeOut: " + e.Message);
                        Dispatcher.Invoke(addMessage, "Timeout for attempt #" + i);
                    }

                    DebuggerIX.WriteLine("[Net]", role, "Initialization = " + ns.IsInitialized);

                    if (ns.IsInitialized == true)
                    {
                        DebuggerIX.WriteLine("[Net]", role, "Sending 'Autentization'");
                        ns.SendAsync(NetworkMessageType.Authentication);
                        ns.AllSentHandle.WaitOne(); // wait until all is sent
                        DebuggerIX.WriteLine("[Net]", role, "'Autentization' sent");
                        Dispatcher.Invoke(addMessage, "Handshake sent");

                        bool canDisconnect = false;
                        while (canDisconnect == false)
                        {
                            DebuggerIX.WriteLine("[Net]", role, "Start async receiving");
                            ns.ReceiveAsync();
                            DebuggerIX.WriteLine("[Net]", role, "Waiting for a message to be received");
                            ns.ReceivedMessageHandle.WaitOne(5000);

                            NetworkMessageType messageType = ns.GetReceivedMessageType();
                            DebuggerIX.WriteLine("[Net]", role, "Received message: " + messageType);

                            if (messageType == NetworkMessageType.Authentication)
                            {
                                Autentization auth = (Autentization)ns.GetReceivedMessageFromQueue();
                                DebuggerIX.WriteLine("[Net]", role,
                                    string.Format("'Autentization' messaage details: {0}, {1}", auth.Name, auth.IP));

                                Dispatcher.Invoke(addPlayer, auth);
                                Dispatcher.Invoke(addMessage, "Autentization message received");
                            }
                            else if (messageType == NetworkMessageType.DisconnectRequest)
                            {
                                DisconnectRequest dr = (DisconnectRequest)ns.GetReceivedMessageFromQueue();
                                DebuggerIX.WriteLine("[Net]", role, "'DisconnectRequest' was sent by the other side in: " +
                                    dr.DateTime);

                                DebuggerIX.WriteLine("[Net]", role, "Sending 'DisconnectRequestConfirmation' message");
                                ns.SendAsync(NetworkMessageType.DisconnectRequestConfirmation);
                                ns.AllSentHandle.WaitOne();
                                DebuggerIX.WriteLine("[Net]", role, "'DisconnectRequestConfirmation' sent");
                                canDisconnect = true;
                                Dispatcher.Invoke(addMessage, "Send request to end handshake");
                            }
                        }

                        ns.CloseConnection();
                        Dispatcher.Invoke(addMessage, "End of initial handshake");
                        DebuggerIX.WriteLine("[Net]", role, "Connection closed.");
                    }

                    i++;
                }

                Dispatcher.Invoke(addMessage, "All attempts tried. Click 'listen' to begin again.");
            }
            catch (ThreadInterruptedException e)
            {
                DebuggerIX.WriteLine("[Net]", role, "Thread interrupted.");
            }
            finally
            {
                ns.CloseConnection();
                Dispatcher.Invoke(addMessage, "Network connection searching was disabled.");
            }
            DebuggerIX.WriteLine("[Net]", role, "Finished");
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        private void Notify(string prop)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
            }
        }

        #endregion

        private void errorMessage(ErrorMessageSeverity ems, string message)
        {
            if (errorPresenter != null)
            {
                errorPresenter.ErrorMessage(ems, "InitConnection", message);
            }
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            Terminate();
        }

        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnListen_Click(object sender, RoutedEventArgs e)
        {
            this.ListenProcessing();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }

}