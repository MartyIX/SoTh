﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;

namespace Sokoban.Lib
{
    public enum DebuggerMode
    {
        OutputWindow,
        File
    }

    public static class DebuggerIX
    {
        static TextWriter tw;
        static bool isActive = false;
        private static DebuggerMode debuggerMode = DebuggerMode.OutputWindow;

        static DebuggerIX()
        {
        }

        [Conditional("DEBUG")]
        public static void Start(DebuggerMode debuggerMode)
        {
            isActive = true;

            DebuggerIX.debuggerMode = debuggerMode;

            if (debuggerMode == DebuggerMode.File)
            {
                string path = @"D:\Bakalarka\Log\";
                
                if (Directory.Exists(path))
                {
                    string file = path + "Log-" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".txt";
                    tw = new StreamWriter(file, false);
                }
                else
                {
                    DebuggerIX.WriteLine("[Debugger] Path: " + path + " does not exists! Logging is not active!");
                }
            }
        }

        [Conditional("DEBUG")]
        public static void WriteLine(string s)
        {
            if (isActive == true)
            {
                if (debuggerMode == DebuggerMode.OutputWindow)
                {
                    Debug.WriteLine(s);
                }
                else if (debuggerMode == DebuggerMode.File)
                {
                    tw.WriteLine(s);
                }
            }
        }

        [Conditional("DEBUG")]
        public static void WriteLine(string category, string s)
        {
            if (isActive == true)
            {
                WriteLine(category, "General", s);
            }
        }

        [Conditional("DEBUG")]
        public static void WriteLine(string category, string subcategory, string s)
        {
            if (isActive == true)
            {
                string time = DateTime.Now.ToString("HH:mm:ss:fff");

                string message = time + " | " 
                    + category.PadRight(21) 
                    + "  |   "
                    + subcategory.PadRight(27)
                    + "  |   "
                    + s;

                if (debuggerMode == DebuggerMode.OutputWindow)
                {
                    Debug.WriteLine(message);
                }
                else if (debuggerMode == DebuggerMode.File)
                {
                    tw.WriteLine(message);
                }
            }
        }

        [Conditional("DEBUG")]
        public static void Write(string s)
        {
            if (isActive == true)
            {
                if (debuggerMode == DebuggerMode.OutputWindow)
                {
                    Debug.Write(s);
                }
                else if (debuggerMode == DebuggerMode.File)
                {
                    tw.Write(s);
                }
            }
        }


        [Conditional("DEBUG")]
        public static void Close()
        {
            if (isActive)
            {
                if (debuggerMode == DebuggerMode.File)
                {
                    tw.Flush();
                    tw.Close();
                }
            }
        }
    }
}
