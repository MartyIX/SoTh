	Level files with .xsb suffix -- open with menu "Open from text(xsb) file..."
	Level files with other suffix -- open with menu "Open..."

\BoxMan
	Levels from game "BoxMan". 
	Game author: Han Xue wei  (Chinese Name: ��ѧΪ)
	Email: hunter37@21cn.com
	
\Classic306	
	Levels from original Sokoban
	
\JinYou
	Levels made by Jin You  (Chinese Name: ����)
	E-mail: jinyou23@yahoo.com.cn
	
\LiJinYu		
	Levels collected by Li Jin yu  (Chinese Name: �����)
	Email: i6688@icqmail.com
	
\WinSoko
	Levels from game "WinSoko"
	Game author: Robert Vasicek
	Email: rvas01@gmx.net
	Homepage: http://www.mtg.sk/rva/

\WVsoko
	Levels from game "WVsoko"
	Game author: 20603
	Email: 20603@sina.com 
