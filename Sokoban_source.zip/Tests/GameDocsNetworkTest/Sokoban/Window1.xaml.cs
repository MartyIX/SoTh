﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Sokoban;
using Sokoban.Model;
using AvalonDock;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Sokoban.Lib;
using System.Globalization;
using System.Threading;
using Sokoban.View.SetupNetwork;
using Sokoban.Networking;
using Sokoban.Lib.Exceptions;
using DummyObjectImplementations;

namespace Sokoban
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private InitConnection initConnectionDialog;
        private Thread t2;
        private int endTheThread = 0;

        
        public Window1()
        {
            Initialize();
            InitializeComponent();
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US", false); 
            DataContext = this;
        }

        private void Initialize()
        {
            PluginService.Initialize(@"D:\Bakalarka\Sokoban\Main\Plugins");
        }

        private void testList()
        {
            if (initConnectionDialog != null)
            {
                initConnectionDialog.Terminate();
                initConnectionDialog.Close();
            }

            initConnectionDialog = new InitConnection(1,1, new DummyProfileRepository(), null);
            initConnectionDialog.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DebuggerIX.Start(DebuggerMode.OutputWindow);
            loadQuest();            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            DebuggerIX.Close();
        }

        private void loadQuest()
        {
            //string result = Sokoban.Properties.Resources.TestQuest;
            string result = Sokoban.Properties.Resources.SimpleQuest;
            //gameManager.Add(result);
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                loadQuest();
                e.Handled = true;
            }
            else if (e.Key == Key.R)
            {
                gameManager.ActiveGameControl.Reload();
            }
            else if (e.Key == Key.D)
            {
                testList();
            }
            else
            {
                if (gameManager != null && gameManager.ActiveGameControl != null)
                {
                    gameManager.ActiveGameControl.KeyIsDown(sender, e);
                }
            }
        }

        private void Window_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            gameManager.ActiveGameControl.KeyIsUp(sender, e);
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            //testList();
        }


        private void btnStartUser_Click(object sender, RoutedEventArgs e)
        {
            if (t2 != null)
            {
                t2.Interrupt();
            }
            
            ThreadStart methodDelegate = new ThreadStart(runConsument);
            t2 = new Thread(methodDelegate);

            if (t2.ThreadState == System.Threading.ThreadState.Running || 
                t2.ThreadState == System.Threading.ThreadState.WaitSleepJoin)
            {
                t2.Interrupt();
                if (endTheThread == 0)
                {
                    Interlocked.Increment(ref endTheThread);
                }
            }

            t2.Start();
        }

        private void runConsument()
        {
            string role = "Client";
            NetworkClient nc = new NetworkClient("10.0.0.5", 56726);
            DebuggerIX.WriteLine("[Net]", role, "Initialization invoked");

            try
            {
                for (int i = 0; i < 3; i++)
                {
                    Thread.Sleep(3500);

                    try
                    {
                        nc.InitializeConnection();

                    }
                    catch (InvalidStateException e)
                    {
                        DebuggerIX.WriteLine("[Net]", role, "InvalidState: " + e.Message);
                    }
                    DebuggerIX.WriteLine("[Net]", role, "IsInitialized = " + nc.IsInitialized);


                    if (nc.IsInitialized == true)
                    {
                        DebuggerIX.WriteLine("[Net]", role, "Sending 'Autentization'");
                        nc.SendAsync(NetworkMessageType.Authentication);
                        nc.AllSentHandle.WaitOne(); // wait until all is sent
                        DebuggerIX.WriteLine("[Net]", role, "'Autentization' sent");

                        DebuggerIX.WriteLine("[Net]", role, "Receiving 'autentization'");
                        nc.ReceiveAsync();
                        nc.ReceivedMessageHandle.WaitOne(10000);
                        NetworkMessageType messageType = nc.GetReceivedMessageType();
                        DebuggerIX.WriteLine("[Net]", role, "Received message: " + messageType);

                        if (messageType == NetworkMessageType.Authentication)
                        {
                            Autentization auth = (Autentization)nc.GetReceivedMessageFromQueue();
                            DebuggerIX.WriteLine("[Net]", role,
                                string.Format("'Autentization' message details: {0}, {1}", auth.Name, auth.IP));
                        }

                        DebuggerIX.WriteLine("[Net]", role, "Sending 'DisconnectRequest' message");
                        nc.SendAsync(NetworkMessageType.DisconnectRequest);
                        DebuggerIX.WriteLine("[Net]", role, "Waiting for the message to be sent");
                        nc.AllSentHandle.WaitOne();
                        DebuggerIX.WriteLine("[Net]", role, "'DisconnectRequest' was sent");

                        /*
                        bool canDisconnect = false;
                        int errorsInRow = 0;

                        while (canDisconnect == false)
                        {
                            DebuggerIX.WriteLine("[Net]", role, "Start async receiving");
                            nc.ReceiveAsync();
                            DebuggerIX.WriteLine("[Net]", role, "Waiting for a message to be received");
                            nc.ReceivedMessageHandle.WaitOne(5000);

                            messageType = nc.GetReceivedMessageType();
                            DebuggerIX.WriteLine("[Net]", role, "Received message: " + messageType);

                            if (messageType == NetworkMessageType.None)
                            {
                                errorsInRow++;
                                if (errorsInRow == 5) canDisconnect = true;
                            }
                            else
                            {
                                errorsInRow = 0;
                            }

                            if (messageType == NetworkMessageType.DisconnectRequestConfirmation)
                            {
                                canDisconnect = true;

                            }
                        }
                        */
                        nc.CloseConnection();
                        DebuggerIX.WriteLine("[Net]", role, "Connection closed.");
                    }
                }

            }
            catch (ThreadInterruptedException e)
            {
                DebuggerIX.WriteLine("[Net]", role, "Thread2 interrupted.");
            }
            finally
            {
                nc.CloseConnection();
            }

            DebuggerIX.WriteLine("[Net]", role, "Finished");
        }


    }
}