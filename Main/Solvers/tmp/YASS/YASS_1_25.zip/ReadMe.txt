====================================================
YASS - Yet Another Sokoban Solver - For Small Levels
Version 1.25
Copyright (c) 2004 by Brian Damgaard, Denmark
E-mail: Brian.Damgaard@e-mail.dk
====================================================

Sokoban(r) Registered Trademark of Falcon Co., Ltd., Japan
Sokoban Copyright (c) 1982-2004 by Hiroyuki Imabayashi, Japan
Sokoban Copyright (c) 1989, 1990, 2001-2004 by Falcon Co., Ltd., Japan


License
--------

YASS - Yet Another Sokoban Solver
Copyright (c) 2004 by Brian Damgaard, Denmark

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

To view the license online, go to: http://www.gnu.org/copyleft/gpl.html


Credits and Acknowledgments
---------------------------

Many people have contributed to this program, and I'm particularly
indebted to:

. Lee J Haywood for providing most of the basic deadlock patterns,
  for sharing a lot of ideas, and for a long-standing correspondence
  on Sokoban issues.

. Andreas Stabel for making 'RBox', a freeware Sokoban solver program 
  that has been an invaluable verification tool.


The Program
-----------
The program finds push-optimal solutions or move-optimal solutions.

Push-optimal solutions may not be optimal in the sense that there
can be other solutions of the same length which use fewer
non-pushing player-moves.

Move-optimal solutions are optimal, but the search is much slower
than searching for push-optimal solutions.

Solving Sokoban levels is a complicated task for a computer program,
hence, the program can only handle small levels.


Usage
-----

Usage: YASS <filename> [options]

Options:
  -deadlocks <number>           : deadlock-sets complexity level 0-3, default 1
  -depth     <number>           : start search depth, default lower bound
  -help                         : this overview
  -level     <number>           : first level number to process, default 1
  -log                          : save search information to a logfile
  -maxpushes <number> (million) : search limit, default 2147 million
  -maxdepth  <number>           : search limit, default 400 pushes
  -memory    <size>   (MB)      : default 64 MB
  -moves                        : find move-optimal solutions (slow)
  -pushes                       : find push-optimal solutions (default)
